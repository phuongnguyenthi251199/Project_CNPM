Translations have moved to
https://translate.wordpress.org/projects/wp-plugins/contact-form-7

Thank you for your contribution.
