<?php

return array(
	array(
		'title' => 'Dark',
		'value' => 'rgba(0,0,0,.5)',
	),
	array(
		'title' => 'White',
		'value' => 'rgba(255,255,255,.5)',
	),
	array(
		'title' => 'Primary',
		'value' => get_theme_mod( 'color_primary', Flatsome_Default::COLOR_PRIMARY ),
	),
);
